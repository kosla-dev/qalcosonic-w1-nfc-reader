# Qalcosonic W1 + PN5180 mechanical package — R1.0

This is the RF-tested production holder orientation for the Qalcosonic W1 NFC reader.

## Files

- `QALCOSONIC_W1_PN5180_R1.0_PRINT_PLATE.3mf` — ready-to-print three-part plate
- `BASE.step` — meter collar / base
- `CARRIER.step` — PN5180 PCB carrier
- `RETAINER.step` — upper PCB retainer / XIAO mounting land

## Print plate

The 3MF contains all three parts as separate objects. The release layout uses 50 mm bounding-box clearance between neighboring groups so slicers do not flag the original crowded layout. The retainer is rotated 90 degrees on the plate only; part geometry is unchanged. Occupied plate area is approximately 198.2 × 212.6 mm, so a 220 × 220 mm or larger build plate is recommended.

## Recommended FDM settings

- 0.4 mm nozzle
- 0.20 mm layer height
- 3 walls
- 5 top / 5 bottom layers
- 20% grid or gyroid infill
- supports OFF
- brim normally OFF
- PETG recommended for long-term installation; PLA is suitable for testing

## Hardware

- 2 × M3 × 8 mm pan-head screws — used in the tested build
- nylon screws are preferred near the NFC assembly

Tighten only until the retainer is seated. Do not bow the PN5180 PCB.

The STEP files are included for users who want to inspect or modify the individual parts. STL duplicates are intentionally omitted because the 3MF already contains the printable meshes.
